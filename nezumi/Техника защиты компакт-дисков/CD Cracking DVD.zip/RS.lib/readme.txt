* Libraries for low-level working with CD sectors from 
CloneCD and Ahead Nero and interfaces to them, with examples of usage

- ElByECC.lib is in Borland format