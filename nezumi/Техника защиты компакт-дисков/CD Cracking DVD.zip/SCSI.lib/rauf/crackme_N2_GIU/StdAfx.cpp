// stdafx.cpp : source file that includes just the standard includes
//	crackme_N2_GIU.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"



